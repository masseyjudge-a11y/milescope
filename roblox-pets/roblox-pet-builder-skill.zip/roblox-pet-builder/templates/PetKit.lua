-- PetKit: builds brick-style pets from a PET spec so every pet shares the same look.
-- Pet space: +X = pet's right, +Y = up, -Z = the way the pet faces. Y = 0 is the ground.
-- Plain Luau (no type annotations, no compound assignment) so it also runs in the preview tool.

local PetKit = {}

-- Upload assets/stud_normal.png and assets/stud_color.png once (Creator Hub or Asset Manager, as
-- Images) and paste the IMAGE ids here. Leave them as 0 and pets build with plain Plastic.
PetKit.STUD_NORMAL_ID = 0
PetKit.STUD_COLOR_ID = 0
PetKit.STUDS_PER_TILE = 1
PetKit.MATERIAL_VARIANT = "PetStuds"
PetKit.MAX_PARTS = 450

local DEFAULT_COLORS = {
	EyeRim = { 30, 20, 24 },
	Iris = { 78, 44, 50 },
	Pupil = { 12, 8, 10 },
	Shine = { 255, 255, 255 },
	Glow = { 255, 250, 200 },
}
-- Roles that keep their colour on Golden pets.
local EYE_ROLES = { EyeRim = true, Iris = true, Pupil = true, Shine = true }

local GOLD_DARK = { 214, 150, 30 }
local GOLD_LIGHT = { 255, 236, 150 }

-- Variants can be combined: PetKit.build(PET, { "Huge", "Golden" }).
PetKit.VARIANTS = {
	Normal = {},
	Huge = { Scale = 2 },
	Golden = { Golden = true, Reflectance = 0.08, Sparkles = { 255, 220, 90 } },
	-- Mutation recolours: the Accent and Glow roles take the new colour (see style.md).
	Green = { Palette = { Accent = { 40, 200, 110 }, Glow = { 60, 255, 170 } } },
	Yellow = { Palette = { Accent = { 200, 220, 40 }, Glow = { 240, 255, 90 } } },
	Orange = { Palette = { Accent = { 235, 120, 30 }, Glow = { 255, 170, 60 } } },
	Pink = { Palette = { Accent = { 220, 40, 170 }, Glow = { 255, 110, 220 } } },
	Purple = { Palette = { Accent = { 120, 40, 220 }, Glow = { 190, 120, 255 } } },
	Cyan = { Palette = { Accent = { 30, 170, 230 }, Glow = { 90, 230, 255 } } },
	-- Rarity effects.
	Secret = { Halo = true },
	Eternal = { Aura = { 255, 110, 190 } },
}

local SHAPES = {
	Block = Enum.PartType.Block,
	Wedge = Enum.PartType.Wedge,
	CornerWedge = Enum.PartType.CornerWedge,
	Cylinder = Enum.PartType.Cylinder,
	Ball = Enum.PartType.Ball,
}

local WORLD_X = Vector3.new(1, 0, 0)
local WORLD_UP = Vector3.new(0, 1, 0)
local WORLD_FRONT = Vector3.new(0, 0, -1)

local function vec(t, s)
	s = s or 1
	return Vector3.new(t[1] * s, t[2] * s, t[3] * s)
end

local function mirrorT(t)
	return { -t[1], t[2], t[3] }
end

local function lerp(a, b, t)
	return a + (b - a) * t
end

local function toColor(c)
	if typeof(c) == "Color3" then
		return c
	end
	return Color3.fromRGB(c[1], c[2], c[3])
end

local function luminance(c)
	return 0.299 * c.R + 0.587 * c.G + 0.114 * c.B
end

local function ensureMaterialVariant()
	if PetKit.STUD_NORMAL_ID == 0 then
		return nil
	end
	local ms = game:GetService("MaterialService")
	local mv = ms:FindFirstChild(PetKit.MATERIAL_VARIANT)
	if not mv then
		mv = Instance.new("MaterialVariant")
		mv.Name = PetKit.MATERIAL_VARIANT
		mv.BaseMaterial = Enum.Material.Plastic
		mv.NormalMap = "rbxassetid://" .. PetKit.STUD_NORMAL_ID
		if PetKit.STUD_COLOR_ID ~= 0 then
			mv.ColorMap = "rbxassetid://" .. PetKit.STUD_COLOR_ID
		end
		mv.StudsPerTile = PetKit.STUDS_PER_TILE
		mv.MaterialPattern = Enum.MaterialPattern.Regular
		mv.Parent = ms
	end
	return mv.Name
end

-- Resolve a colour reference (palette role name or {r,g,b}) through the active variant.
local function resolveColor(ctx, ref)
	local role = nil
	local c
	if type(ref) == "string" then
		role = ref
		local raw = ctx.palette[ref] or DEFAULT_COLORS[ref]
		assert(raw, "PetKit: unknown colour role '" .. ref .. "' (add it to PET.Palette)")
		c = toColor(raw)
	else
		c = toColor(ref)
	end
	if ctx.golden and not (role and EYE_ROLES[role]) then
		c = toColor(GOLD_DARK):Lerp(toColor(GOLD_LIGHT), luminance(c))
	end
	return c
end

local function makePart(ctx, name, shape, size, cf, colorRef, opts)
	opts = opts or {}
	local p = Instance.new("Part")
	p.Name = name
	p.Shape = SHAPES[shape] or error("PetKit: unknown shape " .. tostring(shape))
	p.Size = size
	p.CFrame = cf
	p.Color = resolveColor(ctx, colorRef)
	if opts.Glow then
		p.Material = Enum.Material.Neon
	elseif opts.NoStuds or not ctx.materialVariant then
		p.Material = opts.NoStuds and Enum.Material.SmoothPlastic or Enum.Material.Plastic
	else
		p.Material = Enum.Material.Plastic
		p.MaterialVariant = ctx.materialVariant
	end
	if opts.Transparency then
		p.Transparency = opts.Transparency
	end
	p.Reflectance = ctx.reflectance
	p.TopSurface = Enum.SurfaceType.Smooth
	p.BottomSurface = Enum.SurfaceType.Smooth
	p.Anchored = false
	p.CanCollide = false
	p.CanTouch = false
	p.Massless = true
	local weld = Instance.new("WeldConstraint")
	weld.Part0 = ctx.root
	weld.Part1 = p
	weld.Parent = p
	p.Parent = ctx.model
	ctx.count = ctx.count + 1
	return p
end

-- Frame whose Z runs along `fwd`, Y is as close to world up as possible (or the pet's front for
-- vertical runs) and X points to the pet's right.
local function frameAlong(pos, fwd, upHint)
	local up = upHint or WORLD_UP
	if math.abs(up:Dot(fwd)) > 0.95 then
		up = WORLD_FRONT
	end
	local y = (up - fwd * up:Dot(fwd)).Unit
	local x = y:Cross(fwd)
	local z = fwd
	if x:Dot(WORLD_X) < -0.01 then
		x = -x
		z = -z
	end
	return CFrame.fromMatrix(pos, x, y, z)
end

------------------------------------------------------------------ builders

-- Part: { Type="Part", Name, Shape, Size={x,y,z}, Pos={x,y,z}, Rot={rx,ry,rz} (deg), Color, Glow, NoStuds }
local function buildPart(ctx, s, mirrored)
	local pos = mirrored and mirrorT(s.Pos) or s.Pos
	local r = s.Rot or { 0, 0, 0 }
	local ry, rz = r[2], r[3]
	if mirrored then
		ry, rz = -ry, -rz
	end
	local cf = CFrame.new(vec(pos, ctx.scale)) * CFrame.Angles(math.rad(r[1]), math.rad(ry), math.rad(rz))
	makePart(ctx, s.Name, s.Shape or "Block", vec(s.Size, ctx.scale), cf, s.Color, s)
end

local PAINT_MIRROR = {
	Left = "Right", Right = "Left",
	TopLeft = "TopRight", TopRight = "TopLeft",
	BottomLeft = "BottomRight", BottomRight = "BottomLeft",
	Top = "Top", Bottom = "Bottom",
}

-- One octagonal slice. The four chamfer wedges give the faceted look; paint lets each face
-- take its own colour (koi patches, tiger stripes, pink bellies...).
local function octSlice(ctx, name, cf, w, h, L, cham, base, paint, opts)
	local c = cham * math.min(w, h)
	local function col(key)
		return paint[key] or base
	end
	if c < 0.06 then
		makePart(ctx, name, "Block", Vector3.new(w, h, L), cf, col("Top"), opts)
		return
	end
	local keys = { "Top", "Bottom", "Left", "Right", "TopLeft", "TopRight", "BottomLeft", "BottomRight" }
	local uniform = true
	for _, k in ipairs(keys) do
		if paint[k] and paint[k] ~= base then
			uniform = false
		end
	end
	if uniform then
		makePart(ctx, name, "Block", Vector3.new(w, h - 2 * c, L), cf, base, opts)
		makePart(ctx, name, "Block", Vector3.new(w - 2 * c, h, L), cf, base, opts)
	else
		makePart(ctx, name, "Block", Vector3.new(w - 2 * c, h - 2 * c, L), cf, base, opts)
		makePart(ctx, name .. "Top", "Block", Vector3.new(w - 2 * c, c, L), cf * CFrame.new(0, h / 2 - c / 2, 0), col("Top"), opts)
		makePart(ctx, name .. "Bottom", "Block", Vector3.new(w - 2 * c, c, L), cf * CFrame.new(0, -h / 2 + c / 2, 0), col("Bottom"), opts)
		makePart(ctx, name .. "Right", "Block", Vector3.new(c, h - 2 * c, L), cf * CFrame.new(w / 2 - c / 2, 0, 0), col("Right"), opts)
		makePart(ctx, name .. "Left", "Block", Vector3.new(c, h - 2 * c, L), cf * CFrame.new(-w / 2 + c / 2, 0, 0), col("Left"), opts)
	end
	-- Corner wedges: right angle toward the slice centre, slope facing out.
	local corners = {
		{ "TopRight", 1, 1, 0 },
		{ "TopLeft", -1, 1, 90 },
		{ "BottomLeft", -1, -1, 180 },
		{ "BottomRight", 1, -1, 270 },
	}
	local wedgeBase = CFrame.fromMatrix(Vector3.new(0, 0, 0), Vector3.new(0, 0, 1), Vector3.new(0, 1, 0))
	for _, k in ipairs(corners) do
		local offset = CFrame.new(k[2] * (w / 2 - c / 2), k[3] * (h / 2 - c / 2), 0)
		local wcf = cf * offset * CFrame.Angles(0, 0, math.rad(k[4])) * wedgeBase
		makePart(ctx, name .. k[1], "Wedge", Vector3.new(L, c, c), wcf, col(k[1]), opts)
	end
end

-- Loft: a faceted tube through rings. Bodies, necks, legs, tails, whiskers.
-- { Type="Loft", Name, Color, Steps=2, Chamfer=0.3, Up={x,y,z},
--   Rings = { { Pos={x,y,z}, W=, H=, Color=?, Paint={Top=,Left=,...}?, Steps=? }, ... } }
local function buildLoft(ctx, s, mirrored)
	local rings = s.Rings
	local s0 = ctx.scale
	local cham = s.Chamfer or 0.3
	local up = s.Up and vec(s.Up) or nil
	local pts = {}
	for i, r in ipairs(rings) do
		pts[i] = vec(mirrored and mirrorT(r.Pos) or r.Pos, s0)
	end
	local dirs = {}
	for i = 1, #rings - 1 do
		dirs[i] = (pts[i + 1] - pts[i]).Unit
	end
	for i = 1, #rings - 1 do
		local a, b = rings[i], rings[i + 1]
		local d = pts[i + 1] - pts[i]
		local steps = a.Steps or s.Steps or 1
		local L = d.Magnitude / steps
		local base = a.Color or s.Color
		local paint = {}
		for k, v in pairs(a.Paint or {}) do
			paint[mirrored and PAINT_MIRROR[k] or k] = v
		end
		local bendIn = i > 1 and dirs[i - 1]:Dot(dirs[i]) < 0.9995
		local bendOut = i < #rings - 1 and dirs[i]:Dot(dirs[i + 1]) < 0.9995
		for k = 0, steps - 1 do
			local tm = (k + 0.5) / steps
			local w = lerp(a.W, b.W, tm) * s0
			local h = lerp(a.H, b.H, tm) * s0
			local center = pts[i] + d * tm
			local len = L
			local ext = math.min(w, h) * 0.18
			if k == 0 and bendIn then
				len = len + ext
				center = center - dirs[i] * (ext / 2)
			end
			if k == steps - 1 and bendOut then
				len = len + ext
				center = center + dirs[i] * (ext / 2)
			end
			local cf = frameAlong(center, dirs[i], up)
			octSlice(ctx, s.Name, cf, w, h, len, cham, base, paint, s)
		end
	end
end

-- Fan: a spray of pointed blades. Fins, wings, manes, spikes, tails, crests.
-- Radial (tails, wings): blades spread over `Spread` degrees from one Origin.
-- Row (dorsal fins, manes, spines): give OriginEnd and the blade roots run along a line, with
-- direction and length blending from Dir/Length to DirEnd/LengthEnd.
-- { Type="Fan", Name, Origin, OriginEnd?, Dir (middle/first blade), DirEnd?, Normal (fan plane normal),
--   Spread (deg), Count, Start=0 (gap before the blade begins), Length, LengthEnd?, Taper (0..1: outer
--   blades shorter, negative: longer), Lengths={...}?, Width, Thickness, Color, Tip=role?, TipFrac=0.3,
--   Flip=false (which long edge is straight), Glow }
local function buildFan(ctx, s, mirrored)
	local s0 = ctx.scale
	local function mt(t)
		return t and (mirrored and mirrorT(t) or t) or nil
	end
	local n = vec(s.Normal).Unit
	if mirrored then
		n = Vector3.new(n.X, -n.Y, -n.Z)
	end
	local function inPlane(d)
		d = vec(d)
		return (d - n * d:Dot(n)).Unit -- keep blades in the fan plane
	end
	local origin = vec(mt(s.Origin), s0)
	local originEnd = s.OriginEnd and vec(mt(s.OriginEnd), s0) or origin
	local dir = inPlane(mt(s.Dir))
	local dirEnd = s.DirEnd and inPlane(mt(s.DirEnd)) or dir
	local count = s.Count or 1
	local spread = s.Spread or 0
	local width = (s.Width or 1) * s0
	local thick = (s.Thickness or 0.3) * s0
	local tipFrac = s.TipFrac or 0.3
	for j = 1, count do
		local u = count == 1 and 0.5 or (j - 1) / (count - 1)
		local t = u * 2 - 1
		local a = math.rad(t * spread / 2)
		local bd = CFrame.fromAxisAngle(n, a):VectorToWorldSpace(dir:Lerp(dirEnd, u).Unit)
		local len = s.Lengths and s.Lengths[j] or lerp(s.Length or 3, s.LengthEnd or s.Length or 3, u) * (1 - (s.Taper or 0) * math.abs(t))
		len = len * s0
		local root = origin:Lerp(originEnd, u) + bd * ((s.Start or 0) * s0)
		local center = root + bd * (len / 2)
		local x = n
		local z = -bd
		local y = z:Cross(x)
		if s.Flip then
			x, y = -x, -y
		end
		local cf = CFrame.fromMatrix(center, x, y, z)
		-- Alternate blade thickness slightly so overlapping blades never share a face (z-fighting).
		local th = thick * (1 + 0.05 * ((j - 1) % 2))
		makePart(ctx, s.Name, "Wedge", Vector3.new(th, width, len), cf, s.Color, s)
		if s.Tip then
			local tcf = cf * CFrame.new(0, -width / 2 + width * tipFrac / 2, -len / 2 + len * tipFrac / 2)
			local e = math.max(0.03, 0.02 * width) -- grow the tip a hair so it never shares a face with its blade
			makePart(ctx, s.Name .. "Tip", "Wedge", Vector3.new(th * 1.12, width * tipFrac + 2 * e, len * tipFrac + 2 * e), tcf, s.Tip, s)
		end
	end
end

-- Eye: glossy cartoon eye. { Type="Eye", Pos, Normal (outward), Radius, Iris=role?, Glow, Mirror }
local function buildEye(ctx, s, mirrored)
	local s0 = ctx.scale
	local pos = vec(mirrored and mirrorT(s.Pos) or s.Pos, s0)
	local n = vec(mirrored and mirrorT(s.Normal) or s.Normal).Unit
	local R = s.Radius * s0
	local t = math.max(0.06, R * 0.14)
	local up = WORLD_UP
	if math.abs(up:Dot(n)) > 0.95 then
		up = WORLD_FRONT
	end
	local y = (up - n * up:Dot(n)).Unit
	local cf = CFrame.fromMatrix(pos, n, y)
	local front = WORLD_FRONT - n * WORLD_FRONT:Dot(n)
	if front.Magnitude > 0.05 then
		front = front.Unit
	else
		front = Vector3.new(0, 0, 0)
	end
	local eo = { NoStuds = true }
	local io = { NoStuds = true, Glow = s.Glow }
	makePart(ctx, "EyeRim", "Cylinder", Vector3.new(t, 2 * R, 2 * R), cf, s.Rim or "EyeRim", eo)
	makePart(ctx, "Iris", "Cylinder", Vector3.new(t, 1.7 * R, 1.7 * R), cf + n * (t * 0.35), s.Iris or "Iris", io)
	makePart(ctx, "Pupil", "Cylinder", Vector3.new(t, 0.9 * R, 0.9 * R), cf + n * (t * 0.7), s.Pupil or "Pupil", eo)
	local shinePos = y * (0.42 * R) + front * (0.28 * R) + n * t
	makePart(ctx, "Shine", "Cylinder", Vector3.new(t, 0.42 * R, 0.42 * R), cf + shinePos, "Shine", { NoStuds = true, Glow = true })
end

-- Halo: glowing ring. { Type="Halo", Pos, Radius, Color, Segments=20, Thickness=0.4 }
local function buildHalo(ctx, s)
	local s0 = ctx.scale
	local pos = vec(s.Pos, s0)
	local R = s.Radius * s0
	local seg = s.Segments or 20
	local th = (s.Thickness or 0.4) * s0
	local L = 2 * math.pi * R / seg * 1.08
	for i = 1, seg do
		local a = (i - 0.5) / seg * 2 * math.pi
		local cf = CFrame.new(pos + Vector3.new(math.cos(a) * R, 0, math.sin(a) * R)) * CFrame.Angles(0, -a, 0)
		makePart(ctx, "Halo", "Block", Vector3.new(th, th, L), cf, s.Color or "Glow", { Glow = true })
	end
end

local BUILDERS = { Part = buildPart, Loft = buildLoft, Fan = buildFan, Eye = buildEye, Halo = buildHalo }

local function addParticles(ctx, color, rate, size)
	local att = Instance.new("Attachment")
	att.Name = "FX"
	att.Parent = ctx.root
	local pe = Instance.new("ParticleEmitter")
	pe.Color = ColorSequence.new(toColor(color))
	pe.LightEmission = 1
	pe.Rate = rate
	pe.Lifetime = NumberRange.new(0.8, 1.6)
	pe.Speed = NumberRange.new(1, 3)
	pe.SpreadAngle = Vector2.new(180, 180)
	pe.Size = NumberSequence.new(size * ctx.scale, 0)
	pe.Transparency = NumberSequence.new(0.2, 1)
	pe.Parent = att
	local light = Instance.new("PointLight")
	light.Color = toColor(color)
	light.Range = 12 * ctx.scale
	light.Brightness = 1.5
	light.Parent = ctx.root
end

------------------------------------------------------------------ public API

function PetKit.build(PET, variants, parent)
	if type(variants) == "string" then
		variants = { variants }
	end
	variants = variants or { "Normal" }
	local cfg = { scale = PET.Scale or 1, palette = {}, golden = false, reflectance = 0 }
	for k, v in pairs(PET.Palette or {}) do
		cfg.palette[k] = v
	end
	local label = {}
	for _, name in ipairs(variants) do
		local v = PetKit.VARIANTS[name] or (PET.Variants and PET.Variants[name])
		assert(v, "PetKit: unknown variant '" .. tostring(name) .. "'")
		if name ~= "Normal" then
			table.insert(label, name)
		end
		cfg.scale = cfg.scale * (v.Scale or 1)
		for k, c in pairs(v.Palette or {}) do
			cfg.palette[k] = c
		end
		cfg.golden = cfg.golden or v.Golden == true
		cfg.reflectance = math.max(cfg.reflectance, v.Reflectance or 0)
		cfg.halo = cfg.halo or v.Halo
		cfg.aura = v.Aura or cfg.aura
		cfg.sparkles = v.Sparkles or cfg.sparkles
	end

	local model = Instance.new("Model")
	model.Name = PET.Name .. (#label > 0 and ("_" .. table.concat(label, "_")) or "")
	local root = Instance.new("Part")
	root.Name = "Root"
	root.Size = Vector3.new(1, 1, 1)
	root.CFrame = CFrame.new(0, 0, 0)
	root.Transparency = 1
	root.Anchored = true
	root.CanCollide = false
	root.CanTouch = false
	root.Massless = true
	root.Parent = model
	model.PrimaryPart = root

	local ctx = {
		model = model,
		root = root,
		scale = cfg.scale,
		palette = cfg.palette,
		golden = cfg.golden,
		reflectance = cfg.reflectance,
		materialVariant = ensureMaterialVariant(),
		count = 0,
	}
	for _, item in ipairs(PET.Build) do
		local fn = BUILDERS[item.Type or "Part"] or error("PetKit: unknown Type " .. tostring(item.Type))
		fn(ctx, item, false)
		if item.Mirror then
			fn(ctx, item, true)
		end
	end
	if cfg.halo then
		local halo = PET.HaloAt
		if not halo then -- default: float above the tallest point
			local bcf, bsize = model:GetBoundingBox()
			local top = (bcf.Position.Y + bsize.Y / 2) / ctx.scale
			halo = { Pos = { 0, top + 2.5, bcf.Position.Z / ctx.scale }, Radius = math.max(2, bsize.X / ctx.scale * 0.2) }
		end
		buildHalo(ctx, { Pos = halo.Pos, Radius = halo.Radius, Color = "Glow" })
	end
	if cfg.aura then
		addParticles(ctx, cfg.aura, 40, 1.4)
	end
	if cfg.sparkles then
		addParticles(ctx, cfg.sparkles, 12, 0.6)
	end

	model.WorldPivot = CFrame.new(0, 0, 0) -- bottom centre: pets sit on the ground
	model.Parent = parent or workspace
	local _, size = model:GetBoundingBox()
	print(string.format("PetKit: built %s with %d parts, %.1f x %.1f x %.1f studs", model.Name, ctx.count, size.X, size.Y, size.Z))
	if ctx.count > PetKit.MAX_PARTS then
		warn("PetKit: " .. ctx.count .. " parts is heavy for a following pet; merge or drop small details")
	end
	if PetKit.STUD_NORMAL_ID == 0 then
		warn("PetKit: STUD_NORMAL_ID not set, so the pet has no studs. Upload assets/stud_normal.png and paste its id")
	end
	return model
end

return PetKit
